#  ICE Revision: $Id$ 
""" Infrastructure-Classes

Classes that are needed for setting up configuration directories, servers etc
"""
